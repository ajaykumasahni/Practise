import React from "react";
import { styled } from "@mui/material/styles";
import { Box} from "@mui/material";
import SideNavComp from "../../components/template/SideNav";
import IconTextComp from "../../components/molecules/SideNavTextIcon";
import LeftArrow from "../../images/VectorLeft.svg";
import TypographyComp from "../../components/atoms/typography";
import EmailContainerComp from "../../components/template/EmailContainer";
import CheckBoxTextComp from "../../components/organisms/CheckboxText";

const StyledBox = styled(Box)({
  display: 'flex',
  flex: "1",
});

const StyledBoxSide = styled(Box)({});

const EmailPagination = styled(Box)({
  display: "flex",
  alignItems: "center",
});

const StyledBoxBottom = styled(Box)({

})

const PreviewNotice = styled(Box)({
  
})

const StyledNavBox = styled(Box)({
  flex: "0.15"
})

const StyledAdverseSide = styled(Box)({
  flex: "0.85"
})

const styles = {
  text: {},
};

const AdversePopUp = () => {
  return (
    <StyledBox>
      <StyledNavBox>
      <SideNavComp />
      </StyledNavBox>
       <StyledAdverseSide>
       <StyledBoxSide>
        <IconTextComp
          variant="body1"
          children="Pre adverse action"
          src={LeftArrow}
        />
      </StyledBoxSide>
      <EmailContainerComp />
      <CheckBoxTextComp />

      <TypographyComp
        sx={styles.text}
        children="If you wish to dispute the accuracy of the information in the report directly with the consumer reporting agency (i.e., the source of the informationcontained in the report), you should contact the agency identifield above directly.Sincerely, Checkr-bpo |"
        variant="subtitle2"
      />
       </StyledAdverseSide>
    </StyledBox>
  );
};

export default AdversePopUp;
