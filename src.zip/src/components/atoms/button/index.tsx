import React from 'react'
import {styled} from "@mui/material/styles"
import { Button as MUIButton } from "@mui/material";

export interface ButtonCompProps {
    children: string,
    // textColor: any,
    variantContained: any
  
    sx? :string
}

const StyledButton = styled(MUIButton)({

})

const ButtonComp: React.FC<ButtonCompProps> = ({children, variantContained}) => {
  return (
    <StyledButton style={{textTransform: 'capitalize'}} variant={variantContained}>{children}</StyledButton>
  )
}

export default ButtonComp;