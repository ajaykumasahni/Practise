import React from 'react';

const DialogBoxComp = () => {
  return (
    <div>index</div>
  )
}

export default DialogBoxComp