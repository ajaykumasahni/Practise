import React from 'react'
import { styled } from "@mui/material/styles";
import { Box, Typography } from "@mui/material";
import TypographyComp from '../../atoms/typography';
import ButtonComp from '../../atoms/button';

const StyledBox = styled(Box)({});

const StyledBoxSide = styled(Box)({});

const EmailPagination = styled(Box)({
  display: "flex",
  alignItems: "center",
});

const StyledBoxBottom = styled(Box)({

})

const PreviewNotice = styled(Box)({
  
})

const styles = {
  text: {},
};

const EmailFooterComp = () => {
  return (
    <StyledBoxBottom>
    <EmailPagination>
      <TypographyComp
        sx={styles.text}
        children="Auto send Prev adverse action"
        variant={"subtittle"}
      />
      <ButtonComp children="7" variantContained="outlined" />
      <TypographyComp
        sx={styles.text}
        children="Days"
        variant="subtitle2"
      />
    </EmailPagination>
    <PreviewNotice>
      <ButtonComp variantContained="contained" children="Previre Notice" />
    </PreviewNotice>
  </StyledBoxBottom>
  )
}

export default EmailFooterComp
