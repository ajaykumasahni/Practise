import React from 'react'

import { styled } from "@mui/material/styles";
import { Box } from "@mui/material";
import TypographyComp from '../../atoms/typography';

const StyledBoxInsideEmailContainer = styled(Box)({

})

const EmailFrom = styled(Box)({
  display:'flex',
  alignItems: 'center'
})

const EmailTo = styled(Box)({
  display:'flex',
  alignItems: 'center'
})

const EmailSubject = styled(Box)({
  display:'flex',
  alignItems: 'center'
})

const EmailContent = styled(Box)({

})

const styles = {
  text:{

  }
}


const EmailContainerComp = () => {
  return (
    <StyledBoxInsideEmailContainer>
        <EmailFrom>
          <TypographyComp sx={styles.text} children="From:" variant="subtitle2" />
          <TypographyComp sx={styles.text} children="Kyle@Checkr.Com" variant="subtitle1" />
        </EmailFrom>
        <EmailTo>
        <TypographyComp sx={styles.text} children="To:" variant="subtitle2" />
          <TypographyComp sx={styles.text} children="John Smith@Checkr.Com" variant="subtitle1" />
        </EmailTo>
        <EmailSubject>
          <TypographyComp sx={styles.text} children="Subject:" variant="subtitle2" />
          <TypographyComp sx={styles.text} children="Pre-Adverse Action Notice - checkr- Bpo" variant="subtitle1" />
        </EmailSubject>
        <EmailContent>
          <TypographyComp sx={styles.text} children="Dear John Smith" variant="body2" />
          <TypographyComp sx={styles.text} children="You recently authorized checkr-bpo (“the company”) to obtain consumer reports and/or invistigate consumer reportsabout you from a consumer reporting agency. The Company is considering taking action in whole or in past on information in such report(s) including the following specific items identified in the report prepared by Checkr, Inc." variant="body2" />
        </EmailContent>
      </StyledBoxInsideEmailContainer>
  )
}

export default EmailContainerComp
